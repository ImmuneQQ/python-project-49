# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'brain-game is five games for your brain',
    'long_description': '# brain-games\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ImmuneQQ/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ImmuneQQ/python-project-49/actions)\n<a href="https://codeclimate.com/github/ImmuneQQ/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c804255c965cf3620741/maintainability" /></a>\n\n---\n\n### Description\n\nbrain-game is five games for your brain\n\n---\n\n### Links\n\nThis project was built using these tools:\n\n[poetry](https://poetry.eustace.io/)\n\n---\n\n### Installation\n\npython3 -m pip install --user dist/*.whl\n\n---\n\n### Commands and examples\n\nbrain-even:\n\n[![asciicast](https://asciinema.org/a/szbIJ0PT3lEOmTkPTxBzcfABL.png)](https://asciinema.org/a/szbIJ0PT3lEOmTkPTxBzcfABL)\n\nbrain-calc\n\n[![asciicast](https://asciinema.org/a/T6TCfFwK2JoYK0HwXYw6hdRlQ.png)](https://asciinema.org/a/T6TCfFwK2JoYK0HwXYw6hdRlQ)\n\n\nbrain-gcd\n\n[![asciicast](https://asciinema.org/a/VB8c5pSG8ocGnVTisp9fUEO6j.png)](https://asciinema.org/a/VB8c5pSG8ocGnVTisp9fUEO6j)\n\nbrain-progression\n\n[![asciicast](https://asciinema.org/a/GcUGL0aiUmZTkpKKdKtNgPdIw.png)](https://asciinema.org/a/GcUGL0aiUmZTkpKKdKtNgPdIw)\n\nbrain-prime\n\n[![asciicast](https://asciinema.org/a/hW6zVEy84LqqnvDeadiTqbrqg.png)](https://asciinema.org/a/hW6zVEy84LqqnvDeadiTqbrqg)\n',
    'author': 'immuneqq',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/ImmuneQQ/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
