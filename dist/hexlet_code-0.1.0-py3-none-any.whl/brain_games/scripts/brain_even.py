#!/usr/bin/env python3

import prompt
from brain_games.games import game_even


def main():
    game_even()


if __name__ == '__main__':
    main()
